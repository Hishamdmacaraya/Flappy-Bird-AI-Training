:mod:`ple.games.base`
========================

.. currentmodule:: ple.games.base.pygamewrapper
.. autoclass:: PyGameWrapper
   :members:

.. currentmodule:: ple.games.base.doomwrapper
.. autoclass:: DoomWrapper
   :members:
